const imageInput = document.getElementById("result");
const splitButton = document.getElementById("splitButton");
const downloadButton = document.getElementById("downloadButton");
const imageContainer = document.getElementById("imageContainer");
const dropZone = document.querySelector(".drop-zone");
const imgInputFeild = document.querySelector("#imgInp");
const uploadBtn = document.querySelector("#use");
const reUpLoadBtn = document.querySelector(".re-upload");
const croppieContainer = document.querySelector(".croppie-container");
const selectedImg = document.querySelector("#my-img");

let uploadedImage = null;
let splitImages = [];

function readURL(input) {
  if (input.files && input.files[0]) {
    imageContainer.innerHTML = "";
    var reader = new FileReader();
    reader.onload = function (e) {
      $("#my-image").attr("src", e.target.result);
      var resize = new Croppie($("#my-image")[0], {
        viewport: {
          width: 452,
          height: 906,
        },
        boundary: {
          width: 450,
          height: 911,
        },
        enforceBoundary: false,

        // showZoomer: false,
        enableResize: true,
        enableOrientation: true,
      });
      $("#use").fadeIn();
      $("#use").on("click", function () {
        resize.result("base64").then(function (dataImg) {
          var data = [{ image: dataImg }, { name: "myimgage.jpg" }];
          $(imageInput).attr("src", dataImg);
        });
      });
    };
    reader.readAsDataURL(input.files[0]);
  }
}

$("#imgInp").change(function () {
  readURL(this);
});

imgInputFeild.addEventListener("change", () => {
  imgInputFeild.classList.add("hidden");
  uploadBtn.classList.remove("hidden");
});

uploadBtn.addEventListener("click", () => {
  splitButton.classList.remove("hidden");
});

splitButton.addEventListener("click", () => {
  downloadButton.classList.remove("hidden");
  console.log(downloadButton);
  reUpLoadBtn.classList.remove("hidden");
  uploadBtn.classList.add("hidden");
});

const mmToPixels = (mm) => {
  const dpi = 96; // Standard DPI for most screens
  return (mm * dpi) / 25.4; // 25.4mm = 1 inch
};

splitButton.addEventListener("click", () => {
  if (!imageInput) return;
  imageInput.classList.add("hidden");
  document.querySelector(".croppie-container").classList.add("hidden");

  const imgWidth = 452;
  const imgHeight = 904; // Original height of the input image

  const canvas = document.createElement("canvas");
  canvas.width = imgWidth;
  canvas.height = imgHeight;

  const ctx = canvas.getContext("2d");
  const img = new Image();
  img.src = imageInput.src;

  img.onload = function () {
    ctx.drawImage(img, 0, 0, imgWidth, imgHeight);

    const imageData = ctx.getImageData(0, 0, imgWidth, imgHeight).data;

    splitImages = [];

    // Calculate the height for the two equal parts
    const splitHeight = imgHeight / 2;

    for (let i = 0; i < 2; i++) {
      const startY = i * (imgHeight - splitHeight);

      const splitCanvas = document.createElement("canvas");
      splitCanvas.width = imgWidth;
      splitCanvas.height = splitHeight;

      const splitCtx = splitCanvas.getContext("2d");

      const data = splitCtx.createImageData(imgWidth, splitHeight);

      // Copy the image data from the original image
      for (let y = 0; y < splitHeight; y++) {
        const sourceOffset = (startY + y) * imgWidth * 4;
        const targetOffset = y * imgWidth * 4;

        data.data.set(
          imageData.subarray(sourceOffset, sourceOffset + imgWidth * 4),
          targetOffset
        );
      }

      splitCtx.putImageData(data, 0, 0);

      const splitImg = new Image();
      splitImg.src = splitCanvas.toDataURL();
      splitImg.className = "splitImage";
      splitImages.push(splitImg);
    }

    // Assuming you have an element with id "imageContainer" in your HTML
    const imageContainer = document.getElementById("imageContainer");
    imageContainer.innerHTML = "";
    splitImages.forEach((splitImg) => imageContainer.appendChild(splitImg));

    // Enable the download button
    const downloadButton = document.getElementById("downloadButton");
    downloadButton.disabled = false;
  };
});

// Download button click event handler
downloadButton.addEventListener("click", () => {
  if (!splitImages || splitImages.length !== 2) return;

  // Create download links for each split image
  splitImages.forEach((splitImg, index) => {
    const a = document.createElement("a");
    a.href = splitImg.src;
    a.download = `split_image_${index + 1}.png`;
    a.click();
  });
});
