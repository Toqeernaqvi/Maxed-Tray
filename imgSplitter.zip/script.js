const imageInput = document.getElementById("result");
const splitButton = document.getElementById("splitButton");
const downloadButton = document.getElementById("downloadButton");
const imageContainer = document.getElementById("imageContainer");
const dropZone = document.querySelector(".drop-zone");
const imgInputFeild = document.querySelector("#imgInp");
const uploadBtn = document.querySelector("#use");
const reUpLoadBtn = document.querySelector(".re-upload");
const croppieContainer = document.querySelector(".croppie-container");
const selectedImg = document.querySelector("#my-img");

let uploadedImage = null;
let splitImages = [];

function readURL(input) {
  if (input.files && input.files[0]) {
    imageContainer.innerHTML = "";
    var reader = new FileReader();
    reader.onload = function (e) {
      $("#my-image").attr("src", e.target.result);
      var resize = new Croppie($("#my-image")[0], {
        viewport: {
          width: 120,
          height: 240,
        },
        boundary: {
          width: 300,
          height: 300,
        },
        // showZoomer: false,
        enableResize: true,
        enableOrientation: true,
      });
      $("#use").fadeIn();
      $("#use").on("click", function () {
        resize.result("base64").then(function (dataImg) {
          var data = [{ image: dataImg }, { name: "myimgage.jpg" }];
          $(imageInput).attr("src", dataImg);
        });
      });
    };
    reader.readAsDataURL(input.files[0]);
  }
}

$("#imgInp").change(function () {
  readURL(this);
});

imgInputFeild.addEventListener("change", () => {
  imgInputFeild.classList.add("hidden");
  uploadBtn.classList.remove("hidden");
});

uploadBtn.addEventListener("click", () => {
  splitButton.classList.remove("hidden");
});

splitButton.addEventListener("click", () => {
  downloadButton.classList.remove("hidden");
  console.log(downloadButton);
  reUpLoadBtn.classList.remove("hidden");
  uploadBtn.classList.add("hidden");
});

// uploadBtn.addEventListener("click", () => {
//   document.querySelector(".croppie-container")?.classList.add("hidden");
// });

// imageInput.addEventListener("change", (event) => {
//   const file = event.target.files[0];
//   uploadedImage = URL.createObjectURL(file);

//   const imgElement = document.createElement("img");
//   imgElement.src = uploadedImage;
//   imgElement.className = "splitImage";

//   // Set the fixed height of the displayed image
//   // imgElement.style.height = "560px";

//   imageContainer.innerHTML = "";
//   imageContainer.appendChild(imgElement);
// });

// let scale = 1;

// dropZone.addEventListener("dragover", (e) => {
//   e.preventDefault();
//   dropZone.classList.add("highlight");
// });

// dropZone.addEventListener("dragleave", (e) => {
//   e.preventDefault();
//   dropZone.classList.remove("highlight");
// });

// dropZone.addEventListener("drop", (e) => {
//   e.preventDefault();
//   dropZone.classList.remove("highlight");

//   const file = e.dataTransfer.files[0];
//   handleImage(file);
// });

// imageInput.addEventListener("change", (event) => {
//   event.preventDefault();
//   const file = event.target.files[0];
//   handleImage(file);
// });

// function handleImage(file) {
//   const reader = new FileReader();

//   reader.onload = (event) => {
//     uploadedImage = event.target.result;
//     const imgElement = document.createElement("img");
//     imgElement.src = uploadedImage;
//     imgElement.alt = "Selected Image";
//     imgElement.style.transform = `scale(${scale})`;

//     // Remove any existing image in the container
//     imageContainer.innerHTML = "";

//     // Append the new image element to the container
//     imageContainer.appendChild(imgElement);

//     imgElement.addEventListener("wheel", handleZoom);
//     imgElement.addEventListener("mousedown", startDrag);
//     imgElement.addEventListener("mouseup", endDrag);
//     imgElement.addEventListener("mousemove", handleDrag);
//   };

//   reader.readAsDataURL(file);
// }

let isDragging = false;
let startX, startY, initialLeft, initialTop;

// function startDrag(event) {
//   event.preventDefault();
//   isDragging = true;
//   startX = event.clientX;
//   startY = event.clientY;
//   initialLeft = imageContainer.querySelector("img").offsetLeft;
//   initialTop = imageContainer.querySelector("img").offsetTop;
// }

// function endDrag() {
//   isDragging = false;
// }

// function handleDrag(event) {
//   if (!isDragging) return;
//   const imgElement = imageContainer.querySelector("img");
//   const dx = event.clientX - startX;
//   const dy = event.clientY - startY;
//   imgElement.style.left = `${initialLeft + dx}px`;
//   imgElement.style.top = `${initialTop + dy}px`;
// }

splitButton.addEventListener("click", () => {
  if (!imageInput) return;
  imageInput.classList.add("hidden");
  document.querySelector(".croppie-container").classList.add("hidden");

  const imgWidth = 450;
  const imgHeight = 450;
  const canvas = document.createElement("canvas");
  canvas.width = imgWidth;
  canvas.height = imgHeight;

  const ctx = canvas.getContext("2d");
  const img = new Image();
  img.src = imageInput.src;

  img.onload = function () {
    ctx.drawImage(img, 0, 0, imgWidth, imgHeight);

    const imageData = ctx.getImageData(0, 0, imgWidth, imgHeight).data;

    splitImages = [];

    // Calculate the height for the two equal parts
    const splitHeight = imgHeight / 2;

    for (let i = 0; i < 2; i++) {
      const splitCanvas = document.createElement("canvas");
      splitCanvas.width = imgWidth;
      splitCanvas.height = splitHeight;
      const splitCtx = splitCanvas.getContext("2d");

      const data = splitCtx.createImageData(imgWidth, splitHeight);
      const startY = i * splitHeight;

      // Copy the image data from the original image
      for (let y = 0; y < splitHeight; y++) {
        const sourceOffset = (startY + y) * imgWidth * 4;
        const targetOffset = y * imgWidth * 4;
        data.data.set(
          imageData.subarray(sourceOffset, sourceOffset + imgWidth * 4),
          targetOffset
        );
      }

      splitCtx.putImageData(data, 0, 0);

      const splitImg = new Image();
      splitImg.src = splitCanvas.toDataURL();
      splitImg.className = "splitImage";
      splitImages.push(splitImg);
    }

    imageContainer.innerHTML = "";
    splitImages.forEach((splitImg) => imageContainer.appendChild(splitImg));
  };
});

// downloadButton.addEventListener("click", () => {
//   if (splitImages.length !== 2) return;

//   const a = document.createElement("a");
//   a.href = splitImages[0].src;
//   a.download = "split_image_1.png";
//   a.click();

//   const b = document.createElement("a");
//   b.href = splitImages[1].src;
//   b.download = "split_image_2.png";
//   b.click();
// });
downloadButton.addEventListener("click", () => {
  if (splitImages.length !== 2) return;

  const imgWidth = 1417;
  const imgHeight = 1417;

  const addMetadataOverlay = (image, filename, metadata) => {
    const canvas = document.createElement("canvas");
    canvas.width = imgWidth;
    canvas.height = imgHeight;
    const ctx = canvas.getContext("2d");

    // Load the image
    const img = new Image();
    img.src = image.src;

    img.onload = function () {
      ctx.drawImage(img, 0, 0, imgWidth, imgHeight);

      // Add metadata overlay
      ctx.fillStyle = "rgba(255, 255, 255, 0.7)";
      ctx.fillRect(0, imgHeight - 30, imgWidth, 30);

      ctx.fillStyle = "black";
      ctx.font = "16px Arial";
      ctx.textAlign = "center";
      ctx.fillText(metadata, imgWidth / 2, imgHeight - 10);

      // Create a link to download the modified image
      const a = document.createElement("a");
      a.href = canvas.toDataURL();
      a.download = filename;
      a.click();
    };
  };

  addMetadataOverlay(splitImages[0], "img_part_1.png", "Focal Length: 120mm");
  addMetadataOverlay(splitImages[1], "img_part_2.png", "Focal Length: 120mm");
});
